package com.nagaraj.HibernateDemo;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;

// Java Beans/POJO --> plan old java object
@Entity
public class EmpInfo {
	@Id
	private int eid;
	private String ename;
	private int age;
	public int getEid() {
		return eid;
	}
	public void setEid(int eid) {
		this.eid = eid;
	}
	public String getEname() {
		return ename;
	}
	public void setEname(String ename) {
		this.ename = ename;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	

}
